## logs2graphs

### A python library for extraction of graph data from logs 

#### Supported datasets:
- NOVA
- HDFS
- BGL


#### Authors: 
- Stefan Andonov
- Viktor Jovev
- Aleksandar Kitanovski
- Aleksandar Krstevski